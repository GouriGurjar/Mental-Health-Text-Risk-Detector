import streamlit as st
import pickle
import re
import time
import random
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np

# ─────────────────────────────────────────────
#  PAGE CONFIG
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="MindScan · Mental Health Risk Detector",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────
#  COLOR PALETTE
# ─────────────────────────────────────────────
C = {
    "dark":     "#191D23",
    "teal":     "#57707A",
    "steel":    "#7E919F",
    "mist":     "#979DAB",
    "blush":    "#C5BAC4",
    "fog":      "#DEDCDC",
    "white":    "#FFFFFF",
    "accent":   "#7E919F",
    "danger":   "#C5BAC4",
    "safe":     "#57707A",
}

# ─────────────────────────────────────────────
#  GLOBAL CSS
# ─────────────────────────────────────────────
st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

html, body, [class*="css"] {{
    font-family: 'DM Sans', sans-serif;
    background-color: {C['dark']};
    color: {C['fog']};
}}

#MainMenu, footer, header {{ visibility: hidden; }}

.main .block-container {{
    padding: 2rem 3rem 4rem 3rem;
    max-width: 1200px;
    background: {C['dark']};
}}

[data-testid="stSidebar"] {{
    background: #13171c;
    border-right: 1px solid {C['teal']}33;
}}
[data-testid="stSidebar"] * {{
    color: {C['fog']} !important;
}}

.hero-title {{
    font-family: 'DM Serif Display', serif;
    font-size: 3.2rem;
    line-height: 1.1;
    color: {C['fog']};
    letter-spacing: -0.02em;
}}
.hero-sub {{
    font-size: 1.05rem;
    color: {C['mist']};
    font-weight: 300;
    margin-top: 0.5rem;
    line-height: 1.6;
}}

.card {{
    background: #1e232a;
    border: 1px solid {C['teal']}44;
    border-radius: 16px;
    padding: 1.6rem;
    margin-bottom: 1.2rem;
    transition: border-color 0.25s;
}}
.card:hover {{ border-color: {C['steel']}99; }}

.card-title {{
    font-family: 'DM Serif Display', serif;
    font-size: 1.3rem;
    color: {C['fog']};
    margin-bottom: 0.3rem;
}}
.card-body {{
    font-size: 0.92rem;
    color: {C['mist']};
    line-height: 1.65;
}}

.badge {{
    display: inline-block;
    padding: 0.35rem 1rem;
    border-radius: 100px;
    font-size: 0.82rem;
    font-weight: 600;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    margin-right: 0.5rem;
}}
.badge-low   {{ background: {C['teal']}33;  color: {C['teal']};  border: 1px solid {C['teal']}55; }}
.badge-med   {{ background: {C['steel']}33; color: {C['steel']}; border: 1px solid {C['steel']}55; }}
.badge-high  {{ background: {C['blush']}33; color: {C['blush']}; border: 1px solid {C['blush']}66; }}

.stSlider label {{ color: {C['mist']} !important; font-size: 0.85rem; }}

.stTextArea textarea {{
    background: #1e232a !important;
    color: {C['fog']} !important;
    border: 1px solid {C['teal']}55 !important;
    border-radius: 12px !important;
    font-family: 'DM Sans', sans-serif !important;
    font-size: 0.95rem !important;
    line-height: 1.65 !important;
}}
.stTextArea textarea:focus {{
    border-color: {C['steel']} !important;
    box-shadow: 0 0 0 2px {C['steel']}33 !important;
}}

.stButton > button {{
    background: {C['teal']} !important;
    color: {C['fog']} !important;
    border: none !important;
    border-radius: 100px !important;
    padding: 0.55rem 1.8rem !important;
    font-family: 'DM Sans', sans-serif !important;
    font-weight: 500 !important;
    font-size: 0.9rem !important;
    letter-spacing: 0.04em !important;
    transition: background 0.2s !important;
}}
.stButton > button:hover {{
    background: {C['steel']} !important;
}}

hr {{ border-color: {C['teal']}33 !important; }}

[data-testid="metric-container"] {{
    background: #1e232a;
    border: 1px solid {C['teal']}33;
    border-radius: 14px;
    padding: 1rem 1.2rem;
}}
[data-testid="metric-container"] label {{ color: {C['mist']} !important; font-size: 0.8rem !important; }}
[data-testid="metric-container"] [data-testid="stMetricValue"] {{
    color: {C['fog']} !important;
    font-family: 'DM Serif Display', serif !important;
    font-size: 2rem !important;
}}

[data-baseweb="select"] {{ background: #1e232a !important; }}
.stSelectbox div[data-baseweb="select"] > div {{
    background: #1e232a !important;
    border-color: {C['teal']}55 !important;
    color: {C['fog']} !important;
}}

[data-testid="stExpander"] {{
    background: #1e232a !important;
    border: 1px solid {C['teal']}33 !important;
    border-radius: 12px !important;
}}
[data-testid="stExpander"] summary {{ color: {C['mist']} !important; }}

.stTabs [data-baseweb="tab-list"] {{
    background: #13171c;
    border-radius: 12px;
    padding: 4px;
    gap: 4px;
}}
.stTabs [data-baseweb="tab"] {{
    background: transparent !important;
    color: {C['mist']} !important;
    border-radius: 8px !important;
    font-family: 'DM Sans', sans-serif !important;
}}
.stTabs [aria-selected="true"] {{
    background: {C['teal']} !important;
    color: {C['fog']} !important;
}}
.stTabs [data-baseweb="tab-panel"] {{ padding-top: 1.5rem !important; }}

.stRadio label {{ color: {C['mist']} !important; font-size: 0.9rem !important; }}
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────
#  LOAD MODEL
# ─────────────────────────────────────────────
@st.cache_resource
def load_model():
    try:
        with open("model.pkl", "rb") as f:
            model = pickle.load(f)
        with open("vectorizer.pkl", "rb") as f:
            vectorizer = pickle.load(f)
        return model, vectorizer
    except Exception:
        return None, None

model, vectorizer = load_model()

# ─────────────────────────────────────────────
#  NLP HELPERS — expanded & weighted lexicons
# ─────────────────────────────────────────────
ANXIETY_KEYWORDS = [
    "anxious","anxiety","panic","worried","nervous","overwhelmed","dread",
    "fear","terrified","heart racing","can't breathe","shaking","uneasy",
    "restless","tense","catastrophe","what if","spiral","overthinking",
    "hyperventilate","apprehensive","on edge","dreading","ruminating",
    "sweating","insomnia","racing thoughts","constant worry","freaking out",
]
DEPRESSION_KEYWORDS = [
    "hopeless","worthless","empty","numb","exhausted","tired","dark",
    "crying","alone","lonely","sad","grief","pointless","meaningless",
    "can't get up","no energy","lost","nothing matters","don't care",
    "hollow","disconnected","trapped","invisible","burden","defeated",
    "not myself","depressed","miserable","lifeless","unmotivated","broken",
    "miss my old self","not recognize","don't feel anything","vacant",
]
CRISIS_KEYWORDS = [
    "suicide","kill myself","end my life","die","don't want to live",
    "self harm","hurt myself","no reason to live","give up","want to disappear",
    "make it stop","can't go on","end it","not worth living","ending it all",
]
POSITIVE_KEYWORDS = [
    "happy","grateful","hopeful","better","improving","healing","peaceful",
    "calm","supported","connected","loved","motivated","progress","smile",
    "excited","energized","thriving","joyful","optimistic","content",
    "proud","accomplished","stronger","recovered","light","laughter",
]

# Phrase patterns for multi-word matching
CRISIS_PHRASES = [
    "don't want to live","want to end","end it all","no reason to live",
    "not worth living","want to disappear","can't go on","not worth it",
]
DEPRESSION_PHRASES = [
    "miss my old self","don't recognize","can't get out of bed","can't feel anything",
    "feel like a burden","feel so empty","feel nothing","don't feel like myself",
]

def preprocess(text):
    text = str(text).lower()
    text = re.sub(r'http\S+', '', text)
    text = re.sub(r'[^a-z\s]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def keyword_score(text, keywords, phrases=None):
    text_lower = text.lower()
    hits = [kw for kw in keywords if kw in text_lower]
    if phrases:
        phrase_hits = [ph for ph in phrases if ph in text_lower]
        # Add phrase matches as hits (without duplicating)
        for ph in phrase_hits:
            if ph not in hits:
                hits.append(ph)
    return len(hits), hits

def get_ml_score(text):
    if model is None or vectorizer is None:
        return 0.5, "Model not loaded"
    clean = preprocess(text)
    vec = vectorizer.transform([clean])
    prob = model.predict_proba(vec)[0]
    return float(prob[1]), "ok"

def analyze_text(text):
    if not text.strip():
        return None

    ml_score, status = get_ml_score(text)
    words = text.split()
    word_count = len(words)
    sentences = re.split(r'[.!?]+', text)
    sentence_count = max(1, len([s for s in sentences if s.strip()]))
    avg_sentence_len = word_count / sentence_count

    anx_count, anx_hits = keyword_score(text, ANXIETY_KEYWORDS)
    dep_count, dep_hits = keyword_score(text, DEPRESSION_KEYWORDS, DEPRESSION_PHRASES)
    crisis_count, crisis_hits = keyword_score(text, CRISIS_KEYWORDS, CRISIS_PHRASES)
    pos_count, pos_hits  = keyword_score(text, POSITIVE_KEYWORDS)

    # Normalize keyword density
    density_base = max(1, word_count / 15)
    anx_score = min(1.0, anx_count / density_base)
    kw_dep_score = min(1.0, dep_count / density_base)

    # Depression: ML gets priority (0.70), keywords supplement (0.30)
    dep_score = min(1.0, (ml_score * 0.70) + (kw_dep_score * 0.30))

    # Crisis flag — phrase match gives stronger signal
    crisis_flag = crisis_count > 0

    # Overall risk: weighted fusion
    crisis_boost = 0.45 if crisis_flag else 0.0
    raw_risk = (dep_score * 0.45) + (anx_score * 0.25) + crisis_boost + (kw_dep_score * 0.10)
    overall_risk = min(1.0, raw_risk)

    # Sentiment polarity proxy
    total_signals = max(1, pos_count + dep_count + anx_count)
    sentiment = pos_count / total_signals

    return {
        "ml_score": ml_score,
        "depression_score": dep_score,
        "anxiety_score": anx_score,
        "crisis_flag": crisis_flag,
        "crisis_hits": crisis_hits,
        "overall_risk": overall_risk,
        "word_count": word_count,
        "avg_sentence_len": round(avg_sentence_len, 1),
        "sentiment": sentiment,
        "anx_hits": anx_hits,
        "dep_hits": dep_hits,
        "pos_hits": pos_hits,
    }

def risk_label(score):
    if score >= 0.65:
        return "High", "high"
    elif score >= 0.35:
        return "Moderate", "med"
    else:
        return "Low", "low"

# ─────────────────────────────────────────────
#  COPING STRATEGIES DATABASE
# ─────────────────────────────────────────────
STRATEGIES = {
    "Grounding Techniques": [
        "5-4-3-2-1 method: name 5 things you see, 4 you hear, 3 you can touch, 2 you smell, 1 you taste.",
        "Slowly trace the outline of your hand, breathing in on upstrokes, out on downstrokes.",
        "Place both feet flat on the floor, feel the ground beneath you, and name 3 physical sensations you notice right now.",
    ],
    "Breathing Exercises": [
        "Box breathing: inhale 4s → hold 4s → exhale 4s → hold 4s. Repeat 4 times.",
        "4-7-8 breathing: inhale 4s, hold 7s, exhale 8s — activates the parasympathetic system.",
        "Diaphragmatic breathing: place hand on belly and breathe so only your hand rises.",
    ],
    "Cognitive Strategies": [
        "Write three evidence-based counter-arguments to your most persistent negative thought.",
        "Schedule a 15-minute 'worry window' — postpone rumination until that time.",
        "Use the STOP technique: Stop, Take a breath, Observe, Proceed mindfully.",
    ],
    "Behavioral Activation": [
        "Schedule one small pleasurable activity for tomorrow — even 10 minutes counts.",
        "Take a 20-minute walk outside; natural light regulates circadian rhythms and mood.",
        "Reach out to one trusted person today — social connection is a proven resilience buffer.",
    ],
    "Crisis Resources": [
        "🇮🇳 iCall (India): 9152987821",
        "🌍 International Association for Suicide Prevention: https://www.iasp.info/resources/Crisis_Centres/",
        "💬 Crisis Text Line: Text HOME to 741741 (US/UK/CA/IE)",
        "📞 Vandrevala Foundation (India, 24/7): 1860-2662-345",
    ]
}

def get_strategies(result):
    picks = []
    if result["crisis_flag"]:
        picks.append(("Crisis Resources", STRATEGIES["Crisis Resources"]))
    if result["anxiety_score"] > 0.3:
        picks.append(("Grounding Techniques", STRATEGIES["Grounding Techniques"]))
        picks.append(("Breathing Exercises", STRATEGIES["Breathing Exercises"]))
    if result["depression_score"] > 0.4:
        picks.append(("Behavioral Activation", STRATEGIES["Behavioral Activation"]))
        picks.append(("Cognitive Strategies", STRATEGIES["Cognitive Strategies"]))
    if not picks:
        picks.append(("Breathing Exercises", STRATEGIES["Breathing Exercises"]))
    return picks[:3]

# ─────────────────────────────────────────────
#  PLOTLY THEME
# ─────────────────────────────────────────────
PLOTLY_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font_color=C["mist"],
    font_family="DM Sans",
    margin=dict(l=10, r=10, t=30, b=10),
)

def gauge_chart(value, title, color):
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=round(value * 100),
        number={"suffix": "%", "font": {"size": 28, "color": C["fog"], "family": "DM Serif Display"}},
        title={"text": title, "font": {"size": 13, "color": C["mist"]}},
        gauge={
            "axis": {"range": [0, 100], "tickcolor": C["teal"], "tickwidth": 1, "tickfont": {"size": 10}},
            "bar": {"color": color, "thickness": 0.3},
            "bgcolor": "#1e232a",
            "borderwidth": 0,
            "steps": [
                {"range": [0, 35],  "color": C["teal"] + "22"},
                {"range": [35, 65], "color": C["steel"] + "22"},
                {"range": [65, 100],"color": C["blush"] + "22"},
            ],
        }
    ))
    fig.update_layout(**PLOTLY_LAYOUT, height=200)
    return fig

def radar_chart(result):
    cats = ["Depression Risk", "Anxiety Level", "Crisis Indicators", "Positive Sentiment", "ML Confidence"]
    vals = [
        result["depression_score"],
        result["anxiety_score"],
        min(1.0, len(result["crisis_hits"]) * 0.5),
        result["sentiment"],
        result["ml_score"],
    ]
    fig = go.Figure(go.Scatterpolar(
        r=vals + [vals[0]],
        theta=cats + [cats[0]],
        fill="toself",
        fillcolor=C["teal"] + "33",
        line_color=C["steel"],
        line_width=2,
    ))
    fig.update_layout(
        **PLOTLY_LAYOUT,
        height=280,
        polar=dict(
            bgcolor="#1e232a",
            radialaxis=dict(visible=True, range=[0, 1], tickfont_size=9, gridcolor=C["teal"]+"33"),
            angularaxis=dict(tickfont_size=11, gridcolor=C["teal"]+"33"),
        )
    )
    return fig

def bar_scores(result):
    labels = ["ML Depression", "Anxiety", "Overall Risk", "Positivity"]
    values = [result["ml_score"], result["anxiety_score"], result["overall_risk"], result["sentiment"]]
    colors = [C["steel"], C["blush"], C["mist"], C["teal"]]
    fig = go.Figure(go.Bar(
        x=[v * 100 for v in values],
        y=labels,
        orientation="h",
        marker_color=colors,
        marker_line_width=0,
        text=[f"{v*100:.0f}%" for v in values],
        textfont=dict(color=C["fog"], size=12),
        textposition="inside",
    ))
    fig.update_layout(
        **PLOTLY_LAYOUT,
        height=220,
        xaxis=dict(range=[0, 100], showgrid=False, visible=False),
        yaxis=dict(gridcolor=C["teal"]+"22"),
    )
    return fig

# ─────────────────────────────────────────────
#  SIDEBAR
# ─────────────────────────────────────────────
with st.sidebar:
    st.markdown(f"""
    <div style='padding: 1rem 0 0.5rem 0;'>
        <div style='font-family: DM Serif Display, serif; font-size: 1.6rem; color: {C["fog"]};'>MindScan</div>
        <div style='font-size: 0.75rem; color: {C["mist"]}; letter-spacing: 0.12em; text-transform: uppercase; margin-top: 2px;'>Mental Health Risk Detector</div>
    </div>
    <hr style='border-color: {C["teal"]}33; margin: 0.8rem 0;'/>
    """, unsafe_allow_html=True)

    page = st.radio(
        "Navigate",
        ["🏠  Overview", "🔍  Analyze Text", "📊  Dashboard", "🧘  Coping Strategies", "ℹ️  About"],
        label_visibility="collapsed"
    )

    st.markdown(f"""
    <hr style='border-color: {C["teal"]}33; margin: 1.5rem 0 0.8rem 0;'/>
    <div style='font-size: 0.75rem; color: {C["mist"]}; line-height: 1.6;'>
        <b style='color:{C["fog"]}'>Model:</b> LinearSVC + Calibration<br>
        <b style='color:{C["fog"]}'>Accuracy:</b> 96.5% (test set)<br>
        <b style='color:{C["fog"]}'>Features:</b> TF-IDF (15k, 1–3 ngrams)<br>
        <b style='color:{C["fog"]}'>Dataset:</b> Reddit Depression Corpus<br>
        <b style='color:{C["fog"]}'>Version:</b> 2.0.0
    </div>
    <hr style='border-color: {C["teal"]}33; margin: 1rem 0;'/>
    <div style='font-size: 0.72rem; color: {C["mist"]}; line-height: 1.5;'>
        ⚠️ This tool is for educational purposes only and does not constitute clinical advice.
    </div>
    """, unsafe_allow_html=True)

# ─────────────────────────────────────────────
#  SESSION STATE
# ─────────────────────────────────────────────
if "result" not in st.session_state:
    st.session_state.result = None
if "history" not in st.session_state:
    st.session_state.history = []

# ─────────────────────────────────────────────
#  PAGES
# ─────────────────────────────────────────────

# ── PAGE 0 · OVERVIEW ──────────────
if "Overview" in page:
    st.markdown(f"""
    <div style='margin-bottom: 2rem;'>
        <div class='hero-title'>Understand your<br><span style='color:{C["steel"]};font-style:italic;'>mental landscape.</span></div>
        <p class='hero-sub'>MindScan uses machine-learning to detect depressive and anxious language patterns,<br>
        offering a data-driven window into emotional wellbeing — with empathy at its core.</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"""
        <div class='card'>
            <div style='font-size: 1.8rem; margin-bottom: 0.5rem;'>🔬</div>
            <div class='card-title'>Depression Detection</div>
            <div class='card-body'>A calibrated LinearSVC model trained on 7,731 Reddit posts with TF-IDF (15,000 features, 1–3 n-grams) achieves 96.5% accuracy — correctly predicting both depressive and non-depressive language far beyond simple keyword matching.</div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown(f"""
        <div class='card'>
            <div style='font-size: 1.8rem; margin-bottom: 0.5rem;'>🌀</div>
            <div class='card-title'>Anxiety Analysis</div>
            <div class='card-body'>A 30+ keyword lexicon covering physical symptoms, cognitive distortions, and emotional states maps anxious thought patterns with density-normalised scoring to avoid false positives in longer texts.</div>
        </div>
        """, unsafe_allow_html=True)

    with col2:
        st.markdown(f"""
        <div class='card'>
            <div style='font-size: 1.8rem; margin-bottom: 0.5rem;'>⚠️</div>
            <div class='card-title'>Crisis Flagging</div>
            <div class='card-body'>Real-time phrase and keyword scanning (35+ crisis signals) triggers an immediate alert with curated India-specific and global crisis resources — with direct helpline numbers always visible.</div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown(f"""
        <div class='card'>
            <div style='font-size: 1.8rem; margin-bottom: 0.5rem;'>🧘</div>
            <div class='card-title'>Personalised Coping</div>
            <div class='card-body'>Based on your detected risk profile, the system recommends targeted strategies — grounding, breathing, cognitive reframing, or behavioural activation — matched dynamically to your anxiety and depression scores.</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<hr/>", unsafe_allow_html=True)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Model Accuracy", "96.5%", "↑ from 95.8%")
    c2.metric("Training Posts", "7,731", "Reddit corpus")
    c3.metric("Coping Strategies", "16+", "Evidence-based")
    c4.metric("Risk Dimensions", "5", "Analysed per text")

    st.markdown(f"""
    <div style='margin-top:2rem; padding: 1.2rem 1.6rem; background: {C["teal"]}22;
         border-left: 3px solid {C["teal"]}; border-radius: 0 12px 12px 0;
         color: {C["mist"]}; font-size: 0.88rem; line-height: 1.65;'>
        <b style='color:{C["fog"]}'>How to use:</b> Navigate to <b>Analyze Text</b> in the sidebar, enter any text — a journal entry, a message you wrote, how you're feeling — and MindScan will generate a full risk assessment with personalised recommendations.
    </div>
    """, unsafe_allow_html=True)


# ── PAGE 1 · ANALYZE TEXT ──────────
elif "Analyze" in page:
    st.markdown(f"""
    <div style='margin-bottom: 1.5rem;'>
        <div class='hero-title' style='font-size:2.4rem;'>Text Analysis</div>
        <p class='hero-sub'>Enter any text below. Your input is processed locally and never stored.</p>
    </div>
    """, unsafe_allow_html=True)

    if model is None:
        st.warning("⚠️ model.pkl / vectorizer.pkl not found. Place them in the same directory as app.py. Keyword-based analysis will still run.")

    sample_texts = {
        "Select a sample…": "",
        "Anxious journal entry": "I can't stop overthinking everything. My heart starts racing whenever I think about tomorrow's meeting. What if something goes wrong? I've been shaking and I feel so uneasy all the time.",
        "Depressive reflection": "I feel so empty and worthless. Nothing seems to matter anymore. I'm exhausted but I can't sleep. I've been crying a lot and I feel completely alone. I miss my old self.",
        "Hopeful message": "I'm finally starting to feel a bit better. I went for a walk today and felt grateful for the sunshine. Talking to my friend really helped me feel connected and supported.",
        "Crisis signal": "I don't want to live like this anymore. I keep thinking about ending it all. Nothing is worth it.",
        "Mixed emotions": "I'm trying to stay positive but I feel disconnected from everything. Some days feel okay, others I can't get out of bed. Feeling like a burden to everyone around me.",
    }

    sample_choice = st.selectbox("Try a sample text", list(sample_texts.keys()))
    default_text = sample_texts[sample_choice]

    user_text = st.text_area(
        "Your text",
        value=default_text,
        height=180,
        placeholder="Write freely… describe how you're feeling, paste a journal entry, or type anything on your mind.",
        label_visibility="collapsed",
    )

    col_btn, col_clear = st.columns([1, 5])
    with col_btn:
        analyse_btn = st.button("Analyse →")
    with col_clear:
        if st.button("Clear"):
            st.session_state.result = None
            st.rerun()

    if analyse_btn and user_text.strip():
        with st.spinner("Processing…"):
            time.sleep(0.4)
            result = analyze_text(user_text)
            st.session_state.result = result
            st.session_state.history.append({
                "text": user_text[:80] + "…" if len(user_text) > 80 else user_text,
                "risk": result["overall_risk"],
                "depression": result["depression_score"],
                "anxiety": result["anxiety_score"],
            })

    result = st.session_state.result
    if result:
        st.markdown("<hr/>", unsafe_allow_html=True)

        if result["crisis_flag"]:
            st.markdown(f"""
            <div style='background:{C["blush"]}22; border: 1.5px solid {C["blush"]}; border-radius:14px;
                 padding:1.2rem 1.6rem; margin-bottom:1.2rem;'>
                <div style='font-size:1.1rem; color:{C["blush"]}; font-weight:600; margin-bottom:0.4rem;'>🚨 Crisis Language Detected</div>
                <div style='font-size:0.88rem; color:{C["mist"]}; line-height:1.65;'>
                    The text contains language that may indicate a crisis. Please consider reaching out immediately.<br>
                    <b style='color:{C["fog"]}'>India iCall:</b> 9152987821 &nbsp;|&nbsp;
                    <b style='color:{C["fog"]}'>Vandrevala Foundation (24/7):</b> 1860-2662-345 &nbsp;|&nbsp;
                    <b style='color:{C["fog"]}'>Crisis Text Line:</b> Text HOME to 741741
                </div>
            </div>
            """, unsafe_allow_html=True)

        label, cls = risk_label(result["overall_risk"])
        st.markdown(f"""
        <div style='margin-bottom: 1.2rem;'>
            <span class='badge badge-{cls}'>{label} Risk</span>
            <span style='font-size:0.85rem; color:{C["mist"]};'>Overall risk score: {result["overall_risk"]*100:.0f}/100</span>
        </div>
        """, unsafe_allow_html=True)

        g1, g2, g3, g4 = st.columns(4)
        g1.plotly_chart(gauge_chart(result["depression_score"], "Depression Risk", C["steel"]), use_container_width=True)
        g2.plotly_chart(gauge_chart(result["anxiety_score"],    "Anxiety Level",   C["mist"]),  use_container_width=True)
        g3.plotly_chart(gauge_chart(result["overall_risk"],     "Overall Risk",    C["blush"]), use_container_width=True)
        g4.plotly_chart(gauge_chart(result["sentiment"],        "Positivity",      C["teal"]),  use_container_width=True)

        t1, t2, t3 = st.tabs(["📈 Score Breakdown", "🔎 Keyword Signals", "🧘 Coping Plan"])

        with t1:
            c_bar, c_radar = st.columns([1, 1])
            with c_bar:
                st.markdown(f"<div style='font-size:0.85rem; color:{C['mist']}; margin-bottom:0.5rem;'>Score comparison</div>", unsafe_allow_html=True)
                st.plotly_chart(bar_scores(result), use_container_width=True)
            with c_radar:
                st.markdown(f"<div style='font-size:0.85rem; color:{C['mist']}; margin-bottom:0.5rem;'>Risk profile radar</div>", unsafe_allow_html=True)
                st.plotly_chart(radar_chart(result), use_container_width=True)

            st.markdown(f"""
            <div style='display:flex; gap:1rem; flex-wrap:wrap; margin-top:0.5rem;'>
                <div style='flex:1; min-width:160px; background:#1e232a; border-radius:12px; padding:1rem; border:1px solid {C["teal"]}33;'>
                    <div style='font-size:0.75rem; color:{C["mist"]}; text-transform:uppercase; letter-spacing:0.08em;'>Word Count</div>
                    <div style='font-family: DM Serif Display, serif; font-size:1.8rem; color:{C["fog"]};'>{result["word_count"]}</div>
                </div>
                <div style='flex:1; min-width:160px; background:#1e232a; border-radius:12px; padding:1rem; border:1px solid {C["teal"]}33;'>
                    <div style='font-size:0.75rem; color:{C["mist"]}; text-transform:uppercase; letter-spacing:0.08em;'>Avg Sentence Length</div>
                    <div style='font-family: DM Serif Display, serif; font-size:1.8rem; color:{C["fog"]};'>{result["avg_sentence_len"]}</div>
                </div>
                <div style='flex:1; min-width:160px; background:#1e232a; border-radius:12px; padding:1rem; border:1px solid {C["teal"]}33;'>
                    <div style='font-size:0.75rem; color:{C["mist"]}; text-transform:uppercase; letter-spacing:0.08em;'>ML Confidence</div>
                    <div style='font-family: DM Serif Display, serif; font-size:1.8rem; color:{C["fog"]};'>{result["ml_score"]*100:.0f}%</div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        with t2:
            kw1, kw2, kw3 = st.columns(3)
            with kw1:
                st.markdown(f"<div style='font-size:0.82rem; color:{C['blush']}; font-weight:600; margin-bottom:0.5rem;'>⚠ Depression Signals</div>", unsafe_allow_html=True)
                if result["dep_hits"]:
                    for kw in result["dep_hits"]:
                        st.markdown(f"<span style='background:{C['blush']}22; border-radius:6px; padding:2px 10px; font-size:0.82rem; color:{C['blush']}; margin:2px; display:inline-block;'>{kw}</span>", unsafe_allow_html=True)
                else:
                    st.markdown(f"<span style='color:{C['mist']}; font-size:0.85rem;'>None detected</span>", unsafe_allow_html=True)

            with kw2:
                st.markdown(f"<div style='font-size:0.82rem; color:{C['steel']}; font-weight:600; margin-bottom:0.5rem;'>🌀 Anxiety Signals</div>", unsafe_allow_html=True)
                if result["anx_hits"]:
                    for kw in result["anx_hits"]:
                        st.markdown(f"<span style='background:{C['steel']}22; border-radius:6px; padding:2px 10px; font-size:0.82rem; color:{C['steel']}; margin:2px; display:inline-block;'>{kw}</span>", unsafe_allow_html=True)
                else:
                    st.markdown(f"<span style='color:{C['mist']}; font-size:0.85rem;'>None detected</span>", unsafe_allow_html=True)

            with kw3:
                st.markdown(f"<div style='font-size:0.82rem; color:{C['teal']}; font-weight:600; margin-bottom:0.5rem;'>✨ Positive Signals</div>", unsafe_allow_html=True)
                if result["pos_hits"]:
                    for kw in result["pos_hits"]:
                        st.markdown(f"<span style='background:{C['teal']}22; border-radius:6px; padding:2px 10px; font-size:0.82rem; color:{C['teal']}; margin:2px; display:inline-block;'>{kw}</span>", unsafe_allow_html=True)
                else:
                    st.markdown(f"<span style='color:{C['mist']}; font-size:0.85rem;'>None detected</span>", unsafe_allow_html=True)

        with t3:
            strategies = get_strategies(result)
            for category, tips in strategies:
                st.markdown(f"""
                <div class='card'>
                    <div class='card-title'>{category}</div>
                </div>
                """, unsafe_allow_html=True)
                for tip in tips:
                    st.markdown(f"""
                    <div style='background:#13171c; border-radius:10px; padding:0.7rem 1rem;
                         margin-bottom:0.5rem; color:{C["mist"]}; font-size:0.88rem; line-height:1.6;
                         border-left: 2px solid {C["teal"]}77;'>
                        {tip}
                    </div>
                    """, unsafe_allow_html=True)


# ── PAGE 2 · DASHBOARD ─────────────
elif "Dashboard" in page:
    st.markdown(f"""
    <div style='margin-bottom: 1.5rem;'>
        <div class='hero-title' style='font-size:2.4rem;'>Session Dashboard</div>
        <p class='hero-sub'>Track your analysis history across this session.</p>
    </div>
    """, unsafe_allow_html=True)

    if not st.session_state.history:
        st.markdown(f"""
        <div style='text-align:center; padding: 3rem 1rem; color:{C["mist"]}; font-size:0.95rem;'>
            No analyses yet — head to <b>Analyze Text</b> to get started.
        </div>
        """, unsafe_allow_html=True)
    else:
        df = pd.DataFrame(st.session_state.history)
        df.index = range(1, len(df)+1)
        df["risk_pct"] = (df["risk"] * 100).round(1)

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Analyses", len(df))
        m2.metric("Avg Risk", f"{df['risk_pct'].mean():.1f}%")
        m3.metric("Avg Depression", f"{(df['depression']*100).mean():.1f}%")
        m4.metric("Avg Anxiety",    f"{(df['anxiety']*100).mean():.1f}%")

        st.markdown("<hr/>", unsafe_allow_html=True)

        fig = go.Figure()
        x = list(range(1, len(df)+1))
        fig.add_trace(go.Scatter(x=x, y=(df["risk"]*100).tolist(),       name="Overall Risk",  line=dict(color=C["blush"], width=2.5)))
        fig.add_trace(go.Scatter(x=x, y=(df["depression"]*100).tolist(), name="Depression",    line=dict(color=C["steel"], width=2)))
        fig.add_trace(go.Scatter(x=x, y=(df["anxiety"]*100).tolist(),    name="Anxiety",       line=dict(color=C["mist"],  width=2)))
        fig.update_layout(
            **PLOTLY_LAYOUT,
            height=280,
            title="Score Trends Across Sessions",
            title_font=dict(size=14, color=C["fog"]),
            xaxis=dict(title="Analysis #", gridcolor=C["teal"]+"22"),
            yaxis=dict(title="Score (%)", gridcolor=C["teal"]+"22", range=[0, 105]),
            legend=dict(bgcolor="rgba(0,0,0,0)"),
        )
        st.plotly_chart(fig, use_container_width=True)

        st.markdown(f"<div style='font-size:0.85rem; color:{C['mist']}; margin-bottom:0.5rem;'>Analysis log</div>", unsafe_allow_html=True)
        display_df = df[["text", "risk_pct", "depression", "anxiety"]].copy()
        display_df.columns = ["Text Preview", "Risk %", "Depression", "Anxiety"]
        display_df["Depression"] = (display_df["Depression"] * 100).round(1)
        display_df["Anxiety"]    = (display_df["Anxiety"]    * 100).round(1)
        st.dataframe(display_df, use_container_width=True)


# ── PAGE 3 · COPING STRATEGIES ─────
elif "Coping" in page:
    st.markdown(f"""
    <div style='margin-bottom: 1.5rem;'>
        <div class='hero-title' style='font-size:2.4rem;'>Coping Strategies</div>
        <p class='hero-sub'>Evidence-based techniques to support emotional regulation and resilience.</p>
    </div>
    """, unsafe_allow_html=True)

    st.markdown(f"<div class='card-title' style='margin-bottom:0.8rem;'>Quick Mood Check-In</div>", unsafe_allow_html=True)
    cols = st.columns(3)
    mood = cols[0].slider("😔 Low mood", 0, 10, 5)
    anx  = cols[1].slider("😰 Anxiety",  0, 10, 5)
    enrg = cols[2].slider("⚡ Energy",   0, 10, 5)

    recommended = []
    if mood <= 4:
        recommended += ["Behavioral Activation", "Cognitive Strategies"]
    if anx >= 6:
        recommended += ["Grounding Techniques", "Breathing Exercises"]
    if not recommended:
        recommended = list(STRATEGIES.keys())[:3]
    recommended = list(dict.fromkeys(recommended))[:3]

    st.markdown(f"""
    <div style='margin: 1rem 0 1.5rem; padding:0.8rem 1.2rem; background:{C["teal"]}22;
         border-radius:12px; font-size:0.88rem; color:{C["mist"]};'>
        Based on your check-in, here are your personalised strategies:
    </div>
    """, unsafe_allow_html=True)

    for cat in recommended:
        with st.expander(f"  {cat}"):
            for tip in STRATEGIES[cat]:
                st.markdown(f"""
                <div style='background:#13171c; border-radius:10px; padding:0.7rem 1rem;
                     margin-bottom:0.5rem; color:{C["mist"]}; font-size:0.9rem; line-height:1.65;
                     border-left: 2px solid {C["teal"]}77;'>
                    {tip}
                </div>
                """, unsafe_allow_html=True)

    st.markdown("<hr/>", unsafe_allow_html=True)
    st.markdown(f"<div class='card-title' style='margin-bottom:1rem;'>All Techniques Library</div>", unsafe_allow_html=True)
    for cat, tips in STRATEGIES.items():
        with st.expander(cat):
            for tip in tips:
                st.markdown(f"""
                <div style='background:#13171c; border-radius:10px; padding:0.7rem 1rem;
                     margin-bottom:0.5rem; color:{C["mist"]}; font-size:0.9rem; line-height:1.65;
                     border-left: 2px solid {C["teal"]}77;'>
                    {tip}
                </div>
                """, unsafe_allow_html=True)


# ── PAGE 4 · ABOUT ─────────────────
elif "About" in page:
    st.markdown(f"""
    <div style='margin-bottom: 1.5rem;'>
        <div class='hero-title' style='font-size:2.4rem;'>About MindScan</div>
        <p class='hero-sub'>Project overview, methodology, and important disclaimers.</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns([3, 2])
    with col1:
        st.markdown(f"""
        <div class='card'>
            <div class='card-title'>Project Overview</div>
            <div class='card-body'>
                MindScan is a capstone-grade mental health text risk detector built with Streamlit. It combines supervised machine learning with rule-based NLP to provide a multi-dimensional assessment of emotional wellbeing from free-form text. The tool is designed for educational and research contexts and demonstrates how AI can be applied thoughtfully and responsibly in mental health support technology.
            </div>
        </div>

        <div class='card'>
            <div class='card-title'>Technical Architecture</div>
            <div class='card-body'>
                <b style='color:{C["fog"]}'>Vectorisation:</b> TF-IDF (15,000 features, 1–3 n-grams, sublinear TF scaling) captures richer phrase-level signals including bigrams like "don't care" and "no energy".<br><br>
                <b style='color:{C["fog"]}'>Classifier:</b> LinearSVC (C=0.5, balanced class weights) wrapped in a CalibratedClassifierCV (5-fold, sigmoid) for well-calibrated probability outputs.<br><br>
                <b style='color:{C["fog"]}'>Keyword Engine:</b> 100+ curated signals across depression, anxiety, crisis, and positivity lexicons, with multi-word phrase matching for nuanced detection.<br><br>
                <b style='color:{C["fog"]}'>Risk Fusion:</b> ML probability (70% weight) fused with keyword density (30%) produces depression score; final risk blends depression (45%), anxiety (25%), crisis flags (up to 45% boost).
            </div>
        </div>
        """, unsafe_allow_html=True)

    with col2:
        st.markdown(f"""
        <div class='card'>
            <div class='card-title'>Model Performance</div>
            <div class='card-body'>
                Accuracy: <b style='color:{C["fog"]}'>96.5%</b><br>
                Precision: <b style='color:{C["fog"]}'>97%</b><br>
                Recall: <b style='color:{C["fog"]}'>96%</b><br>
                F1-Score: <b style='color:{C["fog"]}'>97%</b><br>
                Train/Test split: <b style='color:{C["fog"]}'>80/20 stratified</b>
            </div>
        </div>

        <div class='card'>
            <div class='card-title'>Dataset</div>
            <div class='card-body'>
                Reddit Depression Corpus — 7,731 posts balanced across depressive (3,831) and non-depressive (3,900) classes. Preprocessed and cleaned for noise, URLs, and special characters.
            </div>
        </div>

        <div class='card'>
            <div class='card-title'>Key Libraries</div>
            <div class='card-body'>
                streamlit · scikit-learn · plotly<br>
                pandas · numpy · nltk
            </div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown(f"""
    <div style='background:{C["blush"]}11; border: 1px solid {C["blush"]}44; border-radius:14px;
         padding:1.2rem 1.6rem; margin-top:0.5rem;'>
        <div style='font-size:1rem; color:{C["blush"]}; font-weight:600; margin-bottom:0.5rem;'>⚠️ Clinical Disclaimer</div>
        <div style='font-size:0.85rem; color:{C["mist"]}; line-height:1.7;'>
            MindScan is an educational prototype and does <b>not</b> constitute medical or clinical advice. Scores are statistical estimates, not diagnoses. If you or someone you know is experiencing a mental health crisis, please contact a qualified healthcare professional or crisis helpline immediately. This tool should never replace professional mental health assessment.
        </div>
    </div>
    """, unsafe_allow_html=True)
